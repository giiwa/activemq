# 基于giiwa框架的ActiveMQ模块,http://giiwa.org
提供ActiveMQ的基本配置管理，并向其他模块提供MQ API，以实现分布式处理和简化其他模块的开发。
